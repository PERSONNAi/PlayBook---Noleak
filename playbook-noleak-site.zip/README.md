# Noleak Defence | Landing Page do Playbook Comercial

Página única (one page) para divulgar e distribuir o e-book **"Playbook Comercial para Mercados Complexos"** da Noleak Defence, com captura de leads.

- **Link provisório:** https://noleakplaybook.netlify.app/
- **Domínio final (aguardando DNS):** https://playbook.noleakdefence.com/
- **Site principal (projeto separado, no Lovable):** https://www.noleakdefence.com/

> Este projeto é **independente** do site principal. Mexer aqui não afeta o `www.noleakdefence.com`.

---

## Tecnologia

HTML, CSS e JavaScript puros. Não precisa de build, framework nem `npm install`. Para ver a página, basta abrir o `index.html` no navegador.

## Estrutura dos arquivos

| Arquivo | Função |
|---|---|
| `index.html` | Conteúdo da página, metatags de SEO e dados estruturados (Schema.org) |
| `styles.css` | Visual e responsividade |
| `script.js` | Formulário, envio de leads, download do e-book e aviso de cookies |
| `playbook-noleak.pdf` | O e-book entregue ao lead |
| `google-apps-script.js` | **Cópia de referência** do código que roda no Google Apps Script (não é carregado pelo site) |
| `robots.txt` / `sitemap.xml` | Indexação no Google |
| `*.png` / `*.jpg` | Logos, capa do e-book e imagens |

## Para onde vão os leads

Quando alguém preenche o formulário (Nome, E-mail, Telefone, Empresa, Cargo/Função), o `script.js` faz três coisas:

1. **Google Sheets:** envia os dados para um Web App do Google Apps Script, que grava uma linha na planilha. A URL fica na constante `GOOGLE_SHEETS_WEBHOOK_URL`, no topo do `script.js`.
2. **E-mail:** envia uma notificação para `comercial@noleakdefence.com` pelo serviço FormSubmit (constante `DESTINATION_EMAIL`).
3. **WhatsApp:** nas solicitações de diagnóstico, mostra um botão que abre uma conversa com o comercial (constante `WHATSAPP_NUMBER`).

### Se mudar o código do Apps Script

Depois de editar o script na planilha (**Extensões > Apps Script**), é preciso publicar de novo:
**Implantar > Gerenciar implantações > ✏️ Editar > Versão: Nova versão > Implantar.**
Se for gerada uma URL nova, atualize a `GOOGLE_SHEETS_WEBHOOK_URL` no `script.js`.

## SEO, GEO e AEO

- **SEO:** título, descrição, canonical, `robots.txt` e `sitemap.xml`.
- **Redes sociais:** tags Open Graph e Twitter (prévia no WhatsApp e no LinkedIn).
- **GEO / AEO:** dados estruturados Schema.org (`Book`, `WebSite` e `FAQPage`) e uma seção visível de Perguntas Frequentes.

O canonical, o sitemap e as imagens de prévia apontam para `playbook.noleakdefence.com`, então só funcionam por completo depois que o DNS estiver configurado.

## Publicação (Netlify)

Hoje a publicação é manual: compactar os arquivos em `.zip` e arrastar para a área de deploys do site no Netlify.

**Recomendado:** conectar este repositório ao Netlify (*Site configuration > Build & deploy > Link repository*). Assim, cada alteração enviada ao repositório é publicada automaticamente.
Configuração: **build command** vazio e **publish directory** `/` (raiz).

## Pendências

- [ ] **DNS do subdomínio** (feito por quem administra o domínio `noleakdefence.com`). Adicionar dois registros, **sem alterar os que já existem**:

  | Tipo | Nome | Valor |
  |---|---|---|
  | `TXT` | `subdomain-owner-verification` | `c569ff8ac3e93ecc1d3b68727076cbde` |
  | `CNAME` | `playbook` | `noleakplaybook.netlify.app` |

- [ ] Revisar os textos da seção de Perguntas Frequentes.
- [ ] Criar a página de **Política de Privacidade** (o aviso de cookies cita essa política).
