// Google Apps Script - Noleak Defence Lead Integration (Atualizado com Cargo)
// -------------------------------------------------------------
// Como usar:
// 1. Abra sua planilha no Google Sheets
// 2. Vá em Extensões > Apps Script
// 3. Apague tudo e cole o código abaixo
// 4. Clique em "Implantar" > "Nova implantação" > Tipo: "App da Web" > Acesso: "Qualquer pessoa"
// 5. Copie a URL gerada e envie para o chat.

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Cria cabeçalho se a planilha estiver vazia
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["Data e Hora", "Tipo de Solicitação", "Nome", "E-mail Corporativo", "Empresa", "Cargo / Função"]);
    }
    
    var data = JSON.parse(e.postData.contents);
    
    sheet.appendRow([
      data.data || new Date().toLocaleString('pt-BR'),
      data.tipo || 'Download Ebook',
      data.nome || '',
      data.email || '',
      data.empresa || '',
      data.cargo || ''
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({ "result": "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ "result": "error", "message": err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
