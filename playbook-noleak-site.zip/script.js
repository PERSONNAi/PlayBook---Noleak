// Noleak One Page JavaScript & Lead Management

// 1. URL da Web App do Google Apps Script (Planilha Google Sheets Conectada)
const GOOGLE_SHEETS_WEBHOOK_URL = 'https://script.google.com/macros/s/AKfycbzC8c2lOBdC3Up3XRjQJfSk_j4MtsvPyBgMHGmS7UU_a42kirN111xYcH8tku_PlYs2Lw/exec'; 

// 2. Número WhatsApp Comercial Noleak
const WHATSAPP_NUMBER = '5511993392101'; 

// 3. E-mail Comercial
const DESTINATION_EMAIL = 'comercial@noleakdefence.com';

document.addEventListener('DOMContentLoaded', () => {
  // Mobile Nav Toggle
  const mobileToggle = document.getElementById('mobileToggle');
  const navMenu = document.getElementById('navMenu');

  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  }

  // Header Scroll Effect
  const header = document.getElementById('header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      header.style.backgroundColor = 'rgba(10, 31, 60, 0.95)';
      header.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.3)';
    } else {
      header.style.backgroundColor = 'rgba(10, 31, 60, 0.9)';
      header.style.boxShadow = 'none';
    }
  });

  // Modal Elements
  const modal = document.getElementById('contactModal');
  const modalClose = document.getElementById('modalClose');
  const openBtns = document.querySelectorAll('.open-modal-btn');
  const openPdfBtns = document.querySelectorAll('.open-modal-pdf');

  const modalTitle = document.getElementById('modalTitle');
  const modalDesc = document.getElementById('modalDesc');
  const submitBtn = document.getElementById('submitBtn');
  const formTypeInput = document.getElementById('formType');

  function openModal(type, title, desc, btnText) {
    if (formTypeInput) formTypeInput.value = type;
    if (title) modalTitle.textContent = title;
    if (desc) modalDesc.textContent = desc;
    if (btnText && submitBtn) submitBtn.textContent = btnText;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }

  openBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openModal(
        'diagnostico',
        'Solicitar Diagnóstico Comercial',
        'Preencha os dados abaixo para entrarmos em contato e agendarmos um diagnóstico da sua operação comercial.',
        'Enviar solicitação →'
      );
    });
  });

  openPdfBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openModal(
        'ebook',
        'Baixar Playbook Comercial (PDF)',
        'Informe seu nome e e-mail corporativo para fazer o download imediato do Playbook em PDF.',
        'Baixar PDF agora'
      );
    });
  });

  if (modalClose) {
    modalClose.addEventListener('click', closeModal);
  }

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });
  }

  // Atalho de teclado para baixar todos os leads em CSV (Pressione Ctrl + Shift + L)
  window.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'l') {
      exportLeadsCSV();
    }
  });
});

// Manipulador do Envio de Formulário
function handleFormSubmit(event) {
  event.preventDefault();
  
  const form = document.getElementById('contactForm');
  const successMsg = document.getElementById('formSuccess');
  const formType = document.getElementById('formType').value;
  const successTitle = document.getElementById('successTitle');
  const successDesc = document.getElementById('successDesc');
  const whatsappBtnWrapper = document.getElementById('whatsappBtnWrapper');
  const whatsappLink = document.getElementById('whatsappLink');

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const company = document.getElementById('company').value;
  const role = document.getElementById('role').value;
  const phone = document.getElementById('phone').value;
  const now = new Date().toLocaleString('pt-BR');

  const leadData = {
    tipo: formType === 'ebook' ? 'Download Ebook PDF' : 'Solicitação Diagnóstico',
    nome: name,
    email: email,
    telefone: phone,
    empresa: company,
    cargo: role,
    data: now
  };

  // A. Salva no banco de dados local do navegador (localStorage)
  const existingLeads = JSON.parse(localStorage.getItem('noleak_leads') || '[]');
  existingLeads.push(leadData);
  localStorage.setItem('noleak_leads', JSON.stringify(existingLeads));
  console.log('✅ Lead cadastrado com sucesso:', leadData);

  // B. Envia para a Planilha do Google Sheets via API
  if (GOOGLE_SHEETS_WEBHOOK_URL && GOOGLE_SHEETS_WEBHOOK_URL.length > 10) {
    fetch(GOOGLE_SHEETS_WEBHOOK_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(leadData)
    }).then(() => console.log('📊 Lead enviado para a Planilha do Google Sheets!'))
      .catch(err => console.error('Erro Google Sheets:', err));
  }

  // C. Envia notificação por e-mail para comercial@noleakdefence.com via FormSubmit
  try {
    fetch(`https://formsubmit.co/ajax/${DESTINATION_EMAIL}`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        _subject: `Novo Lead Noleak: ${leadData.tipo} - ${name}`,
        Solicitacao: leadData.tipo,
        Nome: name,
        Email: email,
        Telefone: phone,
        Empresa: company,
        Cargo: role,
        Data: now
      })
    });
  } catch (e) {
    console.log('Envio de e-mail efetuado.');
  }

  // D. Lógica separada por tipo de formulário
  if (formType === 'ebook') {
    // --- PLAYBOOK: só faz o download do PDF, sem WhatsApp ---
    successTitle.textContent = 'Download Iniciado!';
    successDesc.innerHTML = 'O download do Playbook Comercial (PDF) foi iniciado. Se não iniciar automaticamente, <a href="playbook-noleak.pdf" download="playbook-comercial-noleak.pdf" style="color:var(--accent-cyan); text-decoration:underline; font-weight:bold;">clique aqui para baixar</a>.';
    whatsappBtnWrapper.style.display = 'none';

    const link = document.createElement('a');
    link.href = 'playbook-noleak.pdf';
    link.download = 'playbook-comercial-noleak.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

  } else {
    // --- DIAGNÓSTICO: abre WhatsApp automaticamente ---
    successTitle.textContent = 'Solicitação Enviada!';
    successDesc.textContent = 'Recebemos suas informações. Nossa equipe comercial vai entrar em contato em breve pelo WhatsApp.';

    const waText = encodeURIComponent(
      `Novo Lead Noleak Defence\n\n` +
      `Solicitacao: ${leadData.tipo}\n` +
      `Nome: ${leadData.nome}\n` +
      `E-mail: ${leadData.email}\n` +
      `Telefone: ${leadData.telefone}\n` +
      `Empresa: ${leadData.empresa}\n` +
      `Cargo: ${leadData.cargo}\n` +
      `Data: ${leadData.data}`
    );
    const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${waText}`;
    whatsappLink.href = waUrl;
    whatsappBtnWrapper.style.display = 'block';
    window.open(waUrl, '_blank');
  }

  form.style.display = 'none';
  successMsg.style.display = 'block';

  setTimeout(() => {
    const modal = document.getElementById('contactModal');
    modal.classList.remove('active');
    document.body.style.overflow = '';

    setTimeout(() => {
      form.reset();
      form.style.display = 'block';
      successMsg.style.display = 'none';
      whatsappBtnWrapper.style.display = 'none';
    }, 400);
  }, 5000);
}


// Função utilitária para exportar todos os leads em CSV
function exportLeadsCSV() {
  const leads = JSON.parse(localStorage.getItem('noleak_leads') || '[]');
  if (leads.length === 0) {
    alert('Nenhum lead registrado ainda.');
    return;
  }

  let csvContent = 'data:text/csv;charset=utf-8,Data,Tipo,Nome,Email,Empresa\n';
  leads.forEach(l => {
    csvContent += `"${l.data}","${l.tipo}","${l.nome}","${l.email}","${l.empresa}"\n`;
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `leads-noleak-${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}


// Cookie Banner Logic
document.addEventListener('DOMContentLoaded', () => {
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookiesBtn = document.getElementById('acceptCookies');

  if (!localStorage.getItem('noleak_cookie_consent')) {
    cookieBanner.style.display = 'block';
  }

  acceptCookiesBtn.addEventListener('click', () => {
    localStorage.setItem('noleak_cookie_consent', 'true');
    cookieBanner.style.display = 'none';
  });
});
